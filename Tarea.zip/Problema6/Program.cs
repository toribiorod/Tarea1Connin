﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema6
{
    class Program
    {
        static void Main(string[] args)
        {
            int f = 0;
            int mul3 = 0;
            int mul5 = 0;
            int cant = 10;
            int valor = 0;

            Console.WriteLine("Debe introducir 10 valores");
            for (f = 1; f <= cant; f++)
            {
                Console.WriteLine("Ingrese el valor  {0}: ", f);
                valor = Convert.ToInt32(Console.ReadLine());
                if (valor % 3 == 0)
                {
                    mul3 = mul3 + 1;
                    if (valor % 5 == 0)
                    {
                        mul5 = mul5 + 1;
                    }
                }
                else if (valor % 5 == 0)
                {
                    mul5 = mul5 + 1;
                }
                else {
                    continue;
                
                }

            }

            Console.WriteLine("Cantidad de números múltiplos de 3: {0}", mul3);
            Console.WriteLine("Cantidad de números múltiplos de 5 : {0}", mul5);
            Console.ReadLine();
        }
    }
}

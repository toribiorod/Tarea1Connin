﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema3
{
    class Program
    {
        static void Main(string[] args)
        {
            int cant1 = 0;
            int cant2 = 0;
            int  cant3 = 0;
            double peso = 0.0;
            int suma = 0;
            do
            {
                Console.WriteLine("Digite el peso en kilogramo o el 0 para terminar");
                peso = Convert.ToDouble(Console.ReadLine());
                if (peso > 10.2)
                {
                    cant1++;
                }
                else if (peso >= 9.2) {
                    cant2++;
                }
                else if (peso > 0) {
                    cant3++;
                }
                } while (peso !=0);
            suma = cant1 + cant2 + cant3;
            Console.WriteLine("La cantidad total pesada es {0}", suma);
            Console.WriteLine("Piezas con un peso con más de 10.2 {0}", cant1);            
            Console.WriteLine("Piezas con un peso entre 9.8 Kg. y 10.2 Kg.? {0}", cant2);
            Console.WriteLine("Piezas con un peso con menos de 9.8 Kg {0}", cant3);
            Console.ReadLine();
        }
    }
}

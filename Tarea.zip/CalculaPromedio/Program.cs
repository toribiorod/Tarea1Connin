﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculaPromedio
{
    class Program
    {
        static void Main(string[] args)
        {
            int suma = 0;
            int cant = 0;
            int valor = 0;
            double promedio=0.0;
            Console.WriteLine("Digite números para obtener su promedio y presione el valor 0 para terminar.");
            do
            {
                Console.WriteLine("Digite un número");
                valor = Convert.ToInt32(Console.ReadLine());                
                if (valor !=0) {
                    suma = suma + valor;
                    cant++;
                }              
                             

            } while (valor != 0);

            if (cant != 0){
                promedio = (double)suma / cant;
                Console.WriteLine("El promedio es {0}", promedio);
            }
            else {
                Console.WriteLine("No se ingrasaron valores");
            }
            
            Console.ReadLine();
        }
    }
}

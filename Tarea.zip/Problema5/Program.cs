﻿using System;

namespace Problema5
{
    class Program
    {
        static void Main(string[] args)
        {
            int f = 0;
            int aprobados = 0;
            int reprobados = 0;
            int cant = 10;
            int notas = 0;

            Console.WriteLine("Debe introducir 10 notas");
            for (f = 1; f <= cant; f++)
            {
                Console.WriteLine("Ingrese la nota  {0}: ", f);
                notas = Convert.ToInt32(Console.ReadLine());
                if (notas >= 7)
                {
                    aprobados = aprobados + 1;
                }
                else {
                    reprobados = reprobados + 1;
                }

            }

            Console.WriteLine("Cantidad de alumnos con notas mayores o iguales a 7: {0}", aprobados);
            Console.WriteLine("Cantidad de alumnos con notas menores a 7 : {0}", reprobados);
            Console.ReadLine();
        }
    }
}

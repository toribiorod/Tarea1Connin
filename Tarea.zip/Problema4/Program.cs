﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema4
{
    class Program
    {
        static void Main(string[] args)
        {
            int suma = 0;
            int f = 0;
            int valor = 0;
            int cant = 10;
            double promedio = 0.0;
            Console.WriteLine("Debe introducir 10 números");
            for (f = 1; f <= cant; f++)
            {
                Console.WriteLine("Ingrese el valor {0} ",f);
                valor = Convert.ToInt32(Console.ReadLine());
                suma = suma + valor;
            }
            promedio = (double)suma / cant;
            Console.WriteLine("La suma  es {0}", suma);
            Console.WriteLine("El promedio es {0}", promedio);
            Console.ReadLine();
        }
    }
}

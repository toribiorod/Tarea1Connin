﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CuentaCifra
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite un número entre 0 y 999 y te diré cuantos digitos tiene  o el 0 para terminar");
            int digito = Convert.ToInt32(Console.ReadLine());
            if (digito !=0) {
                if (digito >= 0 && digito <= 1000 )
                {

                    if (digito >= 100)
                    {
                        Console.WriteLine("El número tiene  3 digitos");
                    }

                    else if (digito >= 10)
                    {
                        Console.WriteLine("El número tiene  2 digitos");
                    }
                    else
                    {

                        Console.WriteLine("El número tiene  1 digitos");
                    }
                }
                else
                {
                    Console.WriteLine("El número una cifra diferente a la solicitada");
                    }
                }
            Console.ReadLine();
        }

        }
    }

